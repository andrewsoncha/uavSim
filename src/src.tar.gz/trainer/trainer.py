from dataclasses import dataclass, field
from typing import Tuple

from gymnasium import spaces

from src.gym import GridGym
import tensorflow as tf

from src.trainer.utils import DecayParams
from utils import Factory
from tensorflow.keras.optimizers.schedules import ExponentialDecay


def polynomial_activation(layer, degree=3):
    return tf.concat([layer ** d for d in range(1, degree + 1)], axis=-1)


class DiscountCurve:
    def __init__(self, base, rate, steps):
        self.decay = ExponentialDecay(1 - base, decay_rate=rate, decay_steps=steps)
        self.use_decay = rate != 1.0
        self.base = tf.constant(base)

    def __call__(self, step):
        if self.use_decay:
            return 1.0 - self.decay(step)
        else:
            return self.base

    def log_success(self):
        pass


class DiscountSuccessSchedule:
    def __init__(self, base, rate, steps):
        self.decay = ExponentialDecay(1 - base, decay_rate=rate, decay_steps=steps)

        self.successes = tf.Variable(0, dtype=tf.int64)

    @tf.function
    def log_success(self):
        self.successes.assign_add(1)

    @tf.function
    def __call__(self, step):
        return 1.0 - self.decay(self.successes)

# This method is made by Andrew to pass as an argument-less function
# to be used as default factory method. This is to use the field 
# instead of passing a mutable object as a default value for dataclass
# Andrew Chang - June 10th, 2026.

def decayMethod():
    return DecayParams(0.96, 0.5, 1_000_000)

class BaseTrainer:
    @dataclass
    class Params:
        training_steps: int = 2_000_000
        gamma: DecayParams = field(default_factory = decayMethod)

    def __init__(self, gym: GridGym):
        self.gym = gym
        action_space = gym.action_space
        assert isinstance(action_space, spaces.Discrete)
        self.action_space: spaces.Discrete = action_space
        self.observation_space = gym.observation_space

    def get_action(self, obs, greedy=False) -> Tuple[int, float]:
        raise NotImplementedError()

    @staticmethod
    @tf.function
    def _soft_update_tf(network, target_network, alpha):
        weights = network.weights
        target_weights = target_network.weights
        new_weights = [w_new * alpha + w_old * (1. - alpha) for w_new, w_old
                       in zip(weights, target_weights)]
        [target_weight.assign(new_weight) for new_weight, target_weight in zip(new_weights, target_weights)]


class TrainerFactory(Factory):

    @classmethod
    def registry(cls):
        from src.trainer.ppo.ppo import PPOTrainer
        return {
            "ppo": PPOTrainer
        }
